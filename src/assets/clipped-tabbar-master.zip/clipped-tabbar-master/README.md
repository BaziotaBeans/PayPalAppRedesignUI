# Clipped TabBar

[DEMO](https://exp.host/@melnyk/clipped-tabbar)

| Preview iOS | Preview Android |
| --- | --- |
| ![PREVIEW IOS](./PREVIEW_IOS.png?raw=true) | ![PREVIEW ANDROID](./PREVIEW_ANDROID.png?raw=true) |
