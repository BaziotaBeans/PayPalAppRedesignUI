import React from 'react';
import { TabBar } from './src/navigation';

export default function App() {
  return (
    <TabBar
      barColor="#F6F7EB"
    />
  );
}
